t = tuple (["mango","uvas","peras","manzanas","piña"])
prin(t[::2])
