# Ejemplo de creacion de listas

#forma de crear lista vacia
 #mis_frutas = [ ]

#Lista con elementos

mis_frutas = ["fresas", "manzana", "mango", "pera", "naranja", "piña"]
print(mis_frutas)

pass