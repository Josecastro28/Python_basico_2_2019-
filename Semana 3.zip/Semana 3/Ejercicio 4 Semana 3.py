# agregar chiles y mango a verduras y frutas


verduras = ["tomate", "papas", "cebollas", "ajos"]
frutas = ["piña", "naraja", "sandia"]
carnes = ["mortadel", "pollo", "costilla de cerdo"]
limpieza = ["javon", "cloro", "shampoo"]

lista_de_compras = []
lista_de_compras.append (verduras)
lista_de_compras.append (frutas)
lista_de_compras.append (carnes)
lista_de_compras.append (limpieza)

verduras.append("chile")
frutas.append("mango")

print(lista_de_compras)
