#t = tuple (["a","1","2"])

#print(t[0:2])


# Crear una tupla con mango, peras, uvas, manzana

x = tuple (["mango","uvas","peras","manzanas"])
#print(x)

b= tuple (["piña"])

print (x+b)

